# Foody - Food Recipes App Developed in Kotlin

Modern Food Recipes App - Android Development with Kotlin | Online Course

Udemy: https://www.udemy.com/course/modern-food-recipes-app-android-development-with-kotlin/?referralCode=A60525980D41EFB701C8
<br/>

![alt text](https://i.postimg.cc/6pt0GT54/Thumbnail-1.png)
